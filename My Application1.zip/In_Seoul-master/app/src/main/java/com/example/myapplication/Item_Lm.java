package com.example.myapplication;

public class Item_Lm {
    String lm_name;

    public Item_Lm(String lm_name, int num) {
        this.lm_name = lm_name;

    }

    public String getLm_name() {
        return lm_name;
    }
}
