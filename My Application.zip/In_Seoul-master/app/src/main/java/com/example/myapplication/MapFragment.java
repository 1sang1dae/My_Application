package com.example.myapplication;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;


import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.geometry.LatLng;


    public class MapFragment extends Fragment implements OnMapReadyCallback {
        private NaverMap naverMap;
        private static final String ARG_LOCATION = "location";

        public static MapFragment newInstance(String location) {
            MapFragment fragment = new MapFragment();
            Bundle args = new Bundle();
            args.putString(ARG_LOCATION, location);
            fragment.setArguments(args);
            return fragment;
        }

        @Nullable
        @Override
        public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            View view = inflater.inflate(R.layout.fragment_map, container, false);
            FragmentManager fm = getChildFragmentManager();

            MapFragment mapFragment = (MapFragment)fm.findFragmentById(R.id.map);
            if (mapFragment == null) {
                mapFragment = MapFragment.newInstance(ARG_LOCATION);
                fm.beginTransaction().add(R.id.map, mapFragment).commit();
            }
            return view;
        }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {
        this.naverMap = naverMap;

        // TODO: Geocoding 서비스를 사용하여 주소를 위도와 경도로 변환하고,
        // 변환된 위도와 경도를 사용하여 지도에 마커를 추가합니다.

        // 받아온 location 값을 Geocoding을 통해 위도와 경도로 변환해야 합니다.
        // 아래의 코드는 임시로 서울 시청의 좌표를 사용하고 있습니다.
        Marker marker = new Marker();
        marker.setPosition(new LatLng(37.5670135, 126.9783740)); // 이 위치는 서울 시청입니다. 실제 주소의 위도와 경도로 변경해야 합니다.
        marker.setMap(naverMap);
    }
}