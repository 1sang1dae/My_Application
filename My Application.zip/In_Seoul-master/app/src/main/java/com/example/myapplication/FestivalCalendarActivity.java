package com.example.myapplication;//package com.example.myapplication;
//
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.recyclerview.widget.LinearLayoutManager;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.List;
//
//public class FestivalCalendarActivity extends AppCompatActivity implements FestivalAdapter.OnItemClickListener {
//    private RecyclerView recyclerView;
//    private FestivalAdapter adapter;
//    private List<Festival> festivalList;
//
//    private DatabaseReference databaseReference;
//    private String selectedDate;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_calendar);
//
//        recyclerView = findViewById(R.id.festival_list);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//
//        festivalList = new ArrayList<>();
//        adapter = new FestivalAdapter(festivalList, this);
//
//        recyclerView.setAdapter(adapter);
//
//        Calendar calendar = Calendar.getInstance();
//        int year = calendar.get(Calendar.YEAR);
//        int month = calendar.get(Calendar.MONTH) + 1;
//        int day = calendar.get(Calendar.DAY_OF_MONTH);
//
//        selectedDate = year + "-" + month + "-" + day;
//
//        databaseReference = FirebaseDatabase.getInstance().getReference();
//        databaseReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                festivalList.clear();
//
//                if (dataSnapshot.exists()) {
//                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
//                        Festival festival = snapshot.getValue(Festival.class);
//                        String startDate = festival.getFestival_date_start();
//                        String endDate = festival.getFestival_date_end();
//
//                        if (selectedDate.equals(startDate) || selectedDate.equals(endDate)) {
//                            festivalList.add(festival);
//                        }
//                    }
//                }
//
//                adapter.notifyDataSetChanged();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(FestivalCalendarActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
//                Log.w("FestivalActivity", "Failed to read value.", error.toException());
//            }
//        });
//    }
//
//    public void onDateSelected(String date) {
//        selectedDate = date;
//        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                festivalList.clear();
//
//                for (DataSnapshot festivalSnapshot : dataSnapshot.getChildren()) {
//                    Festival festival = festivalSnapshot.getValue(Festival.class);
//                    String startDate = festival.getFestival_date_start();
//                    String endDate = festival.getFestival_date_end();
//
//                    if (isDateInRange(selectedDate, startDate, endDate)) {
//                        festivalList.add(festival);
//                    }
//                }
//                adapter.notifyDataSetChanged();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//                Toast.makeText(FestivalCalendarActivity.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//
//    private boolean isDateInRange(String selectedDate, String startDate, String endDate) {
//        Calendar startCalendar = Calendar.getInstance();
//        startCalendar.set(Calendar.YEAR, Integer.parseInt(startDate.substring(0, 4)));
//        startCalendar.set(Calendar.MONTH, Integer.parseInt(startDate.substring(5, 7)) - 1);
//        startCalendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(startDate.substring(8)));
//
//        Calendar endCalendar = Calendar.getInstance();
//        endCalendar.set(Calendar.YEAR, Integer.parseInt(endDate.substring(0, 4)));
//        endCalendar.set(Calendar.MONTH, Integer.parseInt(endDate.substring(5, 7)) - 1);
//        endCalendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(endDate.substring(8)));
//
//        Calendar selectedCalendar = Calendar.getInstance();
//        selectedCalendar.set(Calendar.YEAR, Integer.parseInt(selectedDate.substring(0, 4)));
//        selectedCalendar.set(Calendar.MONTH, Integer.parseInt(selectedDate.substring(5, 7)) - 1);
//        selectedCalendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(selectedDate.substring(8)));
//
//        return selectedCalendar.compareTo(startCalendar) >= 0 && selectedCalendar.compareTo(endCalendar) <= 0;
//    }
//
//    @Override
//    public void onItemClick(int position) {
//        Festival festival = festivalList.get(position);
//        // 클릭된 축제에 대한 추가 작업 수행
//    }
//}
