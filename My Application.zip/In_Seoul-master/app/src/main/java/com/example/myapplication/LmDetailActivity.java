package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.graphics.Region;
import android.os.Bundle;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;

public class LmDetailActivity extends AppCompatActivity {
    private ViewPager2 pager;
    private TabLayout tabLayout;
    private TextView lm_name;
    private TextView lm_location;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lmdetail);

        pager = findViewById(R.id.pager);
        tabLayout = findViewById(R.id.tab_layout);
        lm_name = findViewById(R.id.lm_name);
        lm_location = findViewById(R.id.lm_location);



        Intent intent = getIntent();
        String id = intent.getStringExtra("id");
        String name = intent.getStringExtra("name");
        String location = intent.getStringExtra("location");
        String contact = intent.getStringExtra("contact");
        String homepage = intent.getStringExtra("homepage");
        String lm_fee = intent.getStringExtra("lm_fee");
        String op_time = intent.getStringExtra("op_time");
        String day_off = intent.getStringExtra("day_off");
        ArrayList<String> hashtag = intent.getStringArrayListExtra("hashtag");
        String description = intent.getStringExtra("description");
        String tip = intent.getStringExtra("tip");
        ArrayList<String> image = intent.getStringArrayListExtra("image");

        // Adapter 생성 및 초기화. 필요에 따라 Fragment와 탭 제목을 추가합니다.
        AdapterTabPager adapter = new AdapterTabPager(this);
        adapter.addFragment(IntroFragment.newInstance(description, tip), "소개");
        adapter.addFragment(OperationFragment.newInstance(contact, homepage, lm_fee, op_time, day_off), "운영정보");
        adapter.addFragment(MapFragment.newInstance(location), "지도");
        adapter.addFragment(new SNSFragment(), "SNS");

        // ViewPager2에 Adapter 설정
        pager.setAdapter(adapter);

        // 슬라이드를 통한 페이지 전환 비활성화
        pager.setUserInputEnabled(false);

        // TabLayout과 ViewPager2 연결
        new TabLayoutMediator(tabLayout, pager,
                (tab, position) -> tab.setText(adapter.getTabTitle(position))
        ).attach();

        //landmark 세부정보 textview에 넣기
        lm_name.setText(name);
        lm_location.setText("주소 : " + location);




    }
}